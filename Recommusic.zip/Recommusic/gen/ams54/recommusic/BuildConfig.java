/** Automatically generated file. DO NOT MODIFY */
package ams54.recommusic;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}