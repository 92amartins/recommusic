/**
 *	Extracted from thread on http://stackoverflow.com/questions/10594534/how-to-get-image-from-web-service-to-android-application by 
 *	http://stackoverflow.com/users/651422/chrishi
 */
package ams54.recommusic;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
// TODO Maybe it is not necessary/good practice to extend AsyncTask in this class, since I am using handler on the other class.
// TODO What if the web service doesnt provide an image file? It should be good to have a default image
public class ImageParser extends AsyncTask<String, Void, Bitmap> {

	@Override
	protected Bitmap doInBackground(String... imageURL) {
		Bitmap bmp = null;	
		
		try {
			bmp = BitmapFactory.decodeStream((InputStream) new URL(imageURL[0]).getContent());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bmp;
	}

}
