package ams54.recommusic;

import org.json.JSONException;

public class NoImageJSONException extends JSONException {

	public NoImageJSONException(String message) {
		super(message);
	}
	
}
