package ams54.recommusic;

import android.widget.ImageView;
import android.widget.TextView;
// TODO Provide class overview. Reference: http://www.codeofaninja.com/2013/09/android-viewholder-pattern-example.html
public class ViewHolder {
	ImageView cover;
	TextView song, artist;
}
