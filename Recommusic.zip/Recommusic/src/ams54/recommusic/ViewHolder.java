package ams54.recommusic;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolder {
	ImageView cover;
	TextView song, artist;
}
