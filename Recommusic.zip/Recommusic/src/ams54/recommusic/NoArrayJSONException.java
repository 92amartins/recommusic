package ams54.recommusic;

import org.json.JSONException;

public class NoArrayJSONException extends JSONException {

	public NoArrayJSONException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
