/**
 * @author Andrei Martins Silva
 * 
 * This class represents a Song. It contains the necessary fields to represent itself such as NAME and ARTIST.
 * It also has fields for storing additional data like IMAGEURL, STREAMLINK and BUYLINK.
 * 
 * Three constructors are provided: Song(), Song(String name, String artist) and 
 * Song(String songName, String artist, String imageURL, String streamLink and String buyLink).
 * 
 * Getters and Setters methods are provided for inputting and outputting information after instantiation.
 * and a toString() method is provided for Debugging.
 * 
 * 
 */
package ams54.recommusic;

import android.graphics.Bitmap;

public class Song {
	protected String name;
	protected String artist;
	protected Bitmap cover;
	protected String streamLink = "http://m.youtube.com/results?search_query=";
	protected String buyLink = "http://www.amazon.co.uk/s/ref=nb_sb_noss?url=search-alias%3Ddigital-music&field-keywords=";

	public Song() {
		name = "";
		artist = "";
	}

	public Song(String songName, String artistName){
		name = songName;
		artist = artistName;
		streamLink += artist + "-" + name;
		buyLink += artist + "-" + name;
	}

	public Song(String songName, String artistName, Bitmap coverImage){
		name = songName;
		artist = artistName;
		cover = coverImage;
		streamLink += artist + "-" + songName;
		buyLink += artist + "-" + songName;
	}
}
