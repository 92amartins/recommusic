/**
 * @author Andrei Martins Silva
 * 
 * This class represents a Song. It contains the necessary fields to represent itself such as NAME and ARTIST.
 * It also has fields for storing additional data like IMAGEURL, STREAMLINK and BUYLINK.
 * 
 * Three constructors are provided: Song(), Song(String name, String artist) and 
 * Song(String songName, String artist, String imageURL, String streamLink and String buyLink).
 * 
 * Getters and Setters methods are provided for inputting and outputting information after instantiation.
 * and a toString() method is provided for Debugging.
 * 
 * 
 */
package ams54.recommusic;

import android.graphics.Bitmap;

public class Song {
	private String NAME;
	private String ARTIST;
	private Bitmap COVER;
	private String STREAMLINK = "http://m.youtube.com/results?search_query=";
	private String BUYLINK = "http://www.amazon.co.uk/s/ref=nb_sb_noss?url=search-alias%3Ddigital-music&field-keywords=";

	public Song() {
		NAME = "";
		ARTIST = "";
	}

	public Song(String songName, String artist){
		NAME = songName;
		ARTIST = artist;
		STREAMLINK += artist + "-" + songName;
		BUYLINK += artist + "-" + songName;
	}

	public Song(String songName, String artist, Bitmap cover, String streamLink, String buyLink){
		NAME = songName;
		ARTIST = artist;
		COVER = cover;
		STREAMLINK = streamLink;
		BUYLINK = buyLink;
	}

	protected String getName() {
		return NAME;
	}

	protected void setName(String songName) {
		NAME = songName;
	}

	protected String getArtist(){
		return ARTIST;
	}

	protected void setArtist(String artist){
		ARTIST = artist;
	}

	protected Bitmap getCover(){
		return COVER;
	}

	protected void setCover(Bitmap cover){
		COVER = cover;
	}

	protected String getStreamLink() {
		return STREAMLINK;
	}
	
	protected String getBuyLink() {
		return BUYLINK;
	}
	
	protected void setLinks(String song, String artist) {
		STREAMLINK += artist + "-" + song;
		BUYLINK += artist + "-" + song;
	}
}
