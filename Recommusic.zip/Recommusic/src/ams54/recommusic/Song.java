/**
 * @author Andrei Martins Silva
 * 
 * This class represents a Song. It contains the necessary fields to represent itself such as NAME and ARTIST.
 * It also has fields for storing additional data like IMAGEURL, STREAMLINK and BUYLINK.
 * 
 * Three constructors are provided: Song(), Song(String name, String artist) and 
 * Song(String songName, String artist, String imageURL, String streamLink and String buyLink).
 * 
 * Getters and Setters methods are provided for inputting and outputting information after instantiation.
 * and a toString() method is provided for Debugging.
 * 
 * 
 */
package ams54.recommusic;

public class Song {
	private String NAME;
	private String ARTIST;
	private String IMAGEURL;
	private String STREAMLINK;
	private String BUYLINK;

	public Song() {
		NAME = "";
		ARTIST = "";
		IMAGEURL = "";
		STREAMLINK = "";
		BUYLINK = "";
	}

	public Song(String songName, String artist){
		NAME = songName;
		ARTIST = artist;
	}

	public Song(String songName, String artist, String imageURL, String streamLink, String buyLink){
		NAME = songName;
		ARTIST = artist;
		IMAGEURL = imageURL;
		STREAMLINK = streamLink;
		BUYLINK = buyLink;
	}

	protected String getName() {
		return NAME;
	}

	protected void setName(String songName) {
		NAME = songName;
	}

	protected String getArtist(){
		return ARTIST;
	}

	protected void setArtist(String artist){
		ARTIST = artist;
	}

	protected String getImageURL(){
		return IMAGEURL;
	}

	protected void setImageURL(String imageURL){
		IMAGEURL = imageURL;
	}

	protected String getStreamLink() {
		return STREAMLINK;
	}

	protected void setStreamLink(String streamLink) {
		STREAMLINK = streamLink;
	}

	protected String getBuyLink() {
		return BUYLINK;
	}

	protected void setBuyLink(String buyLink) {
		BUYLINK = buyLink;
	}

	public String toString(){
		String s = "Song: ";

		s += NAME + "\n";
		s += "Artist: ";
		s += ARTIST + "\n";
		s += "Image Url: ";
		s += IMAGEURL + "\n";
		s += "Stream Link: ";
		s += STREAMLINK + "\n";
		s += "Buy Link: ";
		s += BUYLINK;

		return s;
	}
}
