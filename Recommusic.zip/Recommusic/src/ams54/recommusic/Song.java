package ams54.recommusic;

public class Song {
	private String NAME;
	private String ARTIST;
	private String IMAGEURL;
	private String STREAMLINK;
	private String BUYLINK;
	
	
	public Song(){
		NAME = null;
		ARTIST = null;
		IMAGEURL = null;
		STREAMLINK = null;
		BUYLINK = null;
	}
	
	public Song(String songName, String artist){
		NAME = songName;
		ARTIST = artist;
	}
	
	public Song(String songName, String artist, String imageURL, String streamLink, String buyLink){
		NAME = songName;
		ARTIST = artist;
		IMAGEURL = imageURL;
		STREAMLINK = streamLink;
		BUYLINK = buyLink;
	}
	
	protected String getName() {
		return NAME;
	}
	
	protected void setName(String songName) {
		NAME = songName;
	}
	
	protected String getArtist(){
		return ARTIST;
	}
	
	protected void setArtist(String artist){
		ARTIST = artist;
	}
	
	protected String getImageURL(){
		return IMAGEURL;
	}
	
	protected void setImageURL(String imageURL){
		IMAGEURL = imageURL;
	}

	protected String getStreamLink() {
		return STREAMLINK;
	}

	protected void setSTREAMLINK(String streamLink) {
		STREAMLINK = streamLink;
	}

	protected String getBuyLink() {
		return BUYLINK;
	}

	protected void setBuyLink(String buyLink) {
		BUYLINK = buyLink;
	}
	
	public String toString(){
		String s = "Song: ";
		
		s += NAME + "/n";
		s += "Artist: ";
		s += ARTIST + "/n";
		s += "Image Url: ";
		s += IMAGEURL + "/n";
		s += "Stream Link: ";
		s += STREAMLINK + "/n";
		s += "Buy Link: ";
		s += BUYLINK;
		
		return s;
	}
}
