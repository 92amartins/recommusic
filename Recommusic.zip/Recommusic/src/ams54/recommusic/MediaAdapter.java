package ams54.recommusic;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MediaAdapter extends BaseAdapter {

	private Context context;
	private ArrayList<Song> songs;
	private int size;
	private View V = null;

	public MediaAdapter(Context cxt, ArrayList<Song> list) {
		context = cxt;
		songs = list;
		size = songs.size();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		V = inflater.inflate(R.layout.row, parent, false);

		ImageView coverIcon = (ImageView) V.findViewById(R.id.cover);
		TextView song = (TextView) V.findViewById(R.id.songName);
		TextView artist = (TextView) V.findViewById(R.id.artistName);
		ImageView streamIcon = (ImageView) V.findViewById(R.id.stream);
		ImageView buyIcon = (ImageView) V.findViewById(R.id.buy);

		Song S = songs.get(position);

		song.setText(S.getName());
		artist.setText(S.getArtist());

		return V;
	}

	@Override
	public int getCount() {
		return size;
	}

	@Override
	public Object getItem(int position) {
		return songs.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
}
