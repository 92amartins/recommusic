package ams54.recommusic;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class MediaAdapter extends BaseAdapter {

	private Context context;
	private ArrayList<Song> songs;
	private int size;
	private View V = null;

	public MediaAdapter(Context cxt, ArrayList<Song> list) {
		context = cxt;
		songs = list;
		size = songs.size();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		V = inflater.inflate(R.layout.row, parent, false);

		ImageView coverIcon = (ImageView) V.findViewById(R.id.cover);
		TextView song = (TextView) V.findViewById(R.id.songName);
		TextView artist = (TextView) V.findViewById(R.id.artistName);
		ImageButton streamIcon = (ImageButton) V.findViewById(R.id.stream);
		ImageButton buyIcon = (ImageButton) V.findViewById(R.id.buy);

		Song S = songs.get(position);
		
		Log.i("Song Info", S.toString());

		// Setting the image in ImageView
		ImageParser iP = new ImageParser();
		iP.execute(S.getImageURL());
		try {
			coverIcon.setImageBitmap(iP.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Setting song name and artist in Text Views		
		song.setText(S.getName());
		artist.setText(S.getArtist());

		return V;
	}
	
	@Override
	public int getCount() {
		return size;
	}

	@Override
	public Object getItem(int position) {
		return songs.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
}
