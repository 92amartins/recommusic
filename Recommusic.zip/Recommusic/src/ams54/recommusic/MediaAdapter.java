package ams54.recommusic;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MediaAdapter extends BaseAdapter {

	private Context context;
	private ArrayList<Song> songs;
	private int size;

	public MediaAdapter(Context cxt, ArrayList<Song> list) {
		context = cxt;
		songs = list;
		size = songs.size();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder vHolder;

		if(convertView == null){
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.row, parent, false);

			vHolder = new ViewHolder();
			vHolder.cover = (ImageView) convertView.findViewById(R.id.cover);
			vHolder.song = (TextView) convertView.findViewById(R.id.songName);
			vHolder.artist = (TextView) convertView.findViewById(R.id.artistName);

			convertView.setTag(vHolder);
		}else{
			vHolder = (ViewHolder) convertView.getTag();
		}
		Song S = songs.get(position);

		Log.i("Song Info", S.toString());

		// Setting song data
		vHolder.cover.setImageBitmap(S.cover);					
		vHolder.song.setText(S.name);
		vHolder.artist.setText(S.artist);

		return convertView;
	}

	@Override
	public int getCount() {
		return size;
	}

	@Override
	public Object getItem(int position) {
		return songs.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
}
