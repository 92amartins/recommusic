package ams54.recommusic;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONException;

import android.os.AsyncTask;
import android.util.Log;

public class ServiceHandler extends AsyncTask<Song, Void, ArrayList<Song>> {




	// Service Input Parameters
	private String path;
	private String SONG, ARTIST;
	private final String LIMIT = "10";

	// Service Output Parameters
	private static String response = "";
	private ArrayList<Song> songs;

	// TODO Ensure that I am using POST method calls. And what if the user doesn't have internet connection?
	@Override
	protected ArrayList<Song> doInBackground(Song... song) {

		SONG = song[0].getName();
		ARTIST = song[0].getArtist();

		path = "http://ws.audioscrobbler.com/2.0/?method=track.getsimilar&artist=" + ARTIST + "&track=" + SONG + "&api_key=79e948a578829291fe81afa6d581eb5d&format=json&limit=" + LIMIT;


		try{
			// TODO don't forget to disconnect on finally httpCon.disconnect();
			URL url = new URL(path);
			
			HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
			
			// TODO Verify the fact that both below configurations need to be done before the connection is opened;
			// Setting up the encoding as required by the service provider (Last.fm)
			httpCon.setRequestProperty("Accept-Charset", "UTF-8");
			
			// Disabling caches so the app get new recommendations whenever the user request
			httpCon.setUseCaches(false);
						
			InputStream in = new BufferedInputStream(httpCon.getInputStream());
			BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
			String s = "";
			do{
				s = buffer.readLine();
				response += s;				
			}while(s != null);
		}
		catch(IOException e){
			// TODO Handle IOException;
			e.printStackTrace();
		}
		
		// TODO Remove all Log.i calls after debugging.
		Log.i("response", response);

		try{
			songs = JSONParser.parse(response);
		} 
		catch(JSONException j){
			// TODO Handle JSONException
			j.printStackTrace();
		} 
		catch (FileNotFoundException f) {
			// TODO Auto-generated catch block
			f.printStackTrace();
		}
		
		return songs;		
	}
}
