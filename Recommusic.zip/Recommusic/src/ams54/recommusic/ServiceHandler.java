package ams54.recommusic;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONException;
import android.os.AsyncTask;

public class ServiceHandler extends AsyncTask<String, Void, String> {

	static String response = "";
	private String path;
	private String s = "";

	@Override
	protected String doInBackground(String... song) {
		
		path = "http://ws.audioscrobbler.com/2.0/?method=track.getsimilar&artist=" + song[0] + "&track=" + song[1] + "&api_key=79e948a578829291fe81afa6d581eb5d&format=json";
		
		try{
			URL url = new URL(path);
			HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();

			InputStream in = new BufferedInputStream(httpCon.getInputStream());
			BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
			
			do{
				s = buffer.readLine();
				response += s;				
			}while(s != null);
		}
		catch(IOException e){
			e.printStackTrace();
		}
		
		return response;
	}

	@Override
	protected void onPostExecute(String result) {
		super.onPostExecute(result);

		try {
			this.jHandling(result);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// TODO Generate JSON Object. Fetch the JSON. Find Songs and retrieve
	private void jHandling(String result) throws JSONException, FileNotFoundException{
		
	}
}
