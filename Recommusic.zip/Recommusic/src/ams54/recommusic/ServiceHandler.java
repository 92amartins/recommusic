package ams54.recommusic;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.util.Log;

public class ServiceHandler extends AsyncTask<String, Void, ArrayList<Song>> {

	private static String response = "";
	private String path;
	private String s = "";
	private String SONG, ARTIST, IMAGE, STREAM;
	private final String BUY = "http://www.amazon.co.uk/s/ref=nb_sb_noss?url=search-alias%3Ddigital-music&field-keywords=";
	private ArrayList<Song> songs = new ArrayList<Song>();
	private ArrayList<Song> list = null;

	@Override
	protected ArrayList<Song> doInBackground(String... song) {

		path = "http://ws.audioscrobbler.com/2.0/?method=track.getsimilar&artist=" + song[0] + "&track=" + song[1] + "&api_key=79e948a578829291fe81afa6d581eb5d&format=json";

		try{
			URL url = new URL(path);
			HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();

			InputStream in = new BufferedInputStream(httpCon.getInputStream());
			BufferedReader buffer = new BufferedReader(new InputStreamReader(in));

			do{
				s = buffer.readLine();
				response += s;				
			}while(s != null);
		}
		catch(IOException e){
			Log.e("IO Exception", "IO Exception");
			e.printStackTrace();
		}
			
		try{
			list = jsonHandle(response);
		} 
		catch(JSONException j){
			// TODO Handle JSONException
			j.printStackTrace();
		} 
		catch (FileNotFoundException f) {
			// TODO Auto-generated catch block
			f.printStackTrace();
		}

		return list;		
	}


	// TODO Generate JSON Object. Fetch the JSON. Find Songs and retrieve
	private ArrayList<Song> jsonHandle(String result) throws JSONException, FileNotFoundException{
		JSONObject json = new JSONObject(result);
		JSONObject root = json.getJSONObject("similartracks");
		JSONArray tracks = root.getJSONArray("track");
		Song s;

		//Because we just need the first 10 recommended songs. BUT, FOR PERFORMANCE REASONS IS FAR BETTER TO LIMIT THE NUMBER OF SONGS ON THE SERVICE REQUEST BECAUSE REDUCES NETWORK TRAFFIC.
		for(int i = 0; i < 10; i++){
			JSONObject track = tracks.getJSONObject(i);
			
			SONG = track.getString("name");
			ARTIST = track.getJSONObject("artist").getString("name");
			/*IMAGE = track.getJSONArray("image").getJSONObject(1).getString("#text");
			STREAM = track.getString("url");*/

			s = new Song(SONG, ARTIST);

			songs.add(s);
		}

		return songs;
	}
}
