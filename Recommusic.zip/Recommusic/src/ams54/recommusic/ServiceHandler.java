package ams54.recommusic;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;

public class ServiceHandler extends AsyncTask<String, Void, String> {

	static String response = null;
	
	@Override
	protected String doInBackground(String... arg0) {
		try{
			URL url = new URL("http://ws.audioscrobbler.com/2.0/?method=track.getsimilar&artist=cher&track=believe&api_key=79e948a578829291fe81afa6d581eb5d&format=json");
			HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();

			InputStream in = new BufferedInputStream(httpCon.getInputStream());

			BufferedReader buffer = new BufferedReader(new InputStreamReader(in));
			String s = "";
			while ((s = buffer.readLine()) != null) {
				response += s;
			}
		}
		catch(IOException e){
			e.printStackTrace();
		}
		
		return response;
	}
}
