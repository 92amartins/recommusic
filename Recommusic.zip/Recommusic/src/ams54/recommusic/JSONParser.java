package ams54.recommusic;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public class JSONParser {
	
	// TODO Generate JSON Object. Fetch the JSON. Find Songs and retrieve
	public ArrayList<Song> parse(String jsonStr) throws FileNotFoundException, JSONException{
		
		JSONObject json = new JSONObject(jsonStr);
		Log.i("response", json.toString(5));
		JSONObject root = json.getJSONObject("similartracks");
		JSONArray tracks = root.getJSONArray("track");
		ArrayList<Song> songs = new ArrayList<Song>();
		
		int len = tracks.length();
		
		for(int i = 0; i < len; i++){
			JSONObject track = tracks.getJSONObject(i);
			Song song = new Song();
			
			song.setName(track.getString("name"));
			song.setArtist(track.getJSONObject("artist").getString("name"));
			song.setImageURL(track.getJSONArray("image").getJSONObject(1).getString("#text"));
		    song.setLinks(track.getString("name"), track.getJSONObject("artist").getString("name"));
			
			songs.add(song);
		}
		
		return songs;
	}


}
