package ams54.recommusic;

import java.util.ArrayList;

import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.util.Log;

public class JSONParser extends AsyncTask<Void, Void, String[]>{
	
	private Context context;
	private ProgressDialog pDialog;
	private Cursor cursor;
	private final Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
	private final String[] proj = {MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.TITLE};
	private final String where = MediaStore.Audio.Media.IS_MUSIC + " <> ?";
	private final String sel[] = {"0"};
	private String[] song = new String[2];
	private ArrayList<String> artists, titles;
	private int index;
	
	
	public JSONParser(Context cxt){
		context = cxt;		
	}
	
	@Override
	protected String[] doInBackground(Void... params) {
		artists = new ArrayList<String>();
	    titles  = new ArrayList<String>();
	    
		cursor = context.getContentResolver().query(uri, proj, where, sel, null);
        
		index = (int) (Math.random() * cursor.getCount());
		
		cursor.moveToFirst();
        
		do{
			artists.add(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)));
			titles.add(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)));
		}while(cursor.moveToNext());
        
		cursor.close();
		
		song[0] = artists.get(index);
		song[1] = titles.get(index);
		
		return song;
	}
}
