package ams54.recommusic;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;


public class JSONParser {
	
	// TODO Generate JSON Object. Fetch the JSON. Find Songs and retrieve
	public ArrayList<Song> parse(String jsonStr) throws FileNotFoundException, JSONException{
		
		JSONObject json = new JSONObject(jsonStr);
		JSONObject root = json.getJSONObject("similartracks");
		JSONArray tracks = root.getJSONArray("track");
		ArrayList<Song> songs = new ArrayList<Song>();
		
		int len = tracks.length();
		
		for(int i = 0; i < len; i++){
			JSONObject track = tracks.getJSONObject(i);
			Song song = new Song();
			
			song.setName(track.getString("name"));
			song.setArtist(track.getJSONObject("artist").getString("name"));
//			song.setImageURL(track.getJSONArray("image").getJSONObject(1).getString("#text"));
			song.setCover(getBitmap(track.getJSONArray("image").getJSONObject(1).getString("#text")));
		    song.setLinks(track.getString("name"), track.getJSONObject("artist").getString("name"));
			
			songs.add(song);
		}
		
		return songs;
	}
	
	// TODO What if the web service doesnt provide an image file? It should be good to have a default image
	private static Bitmap getBitmap(String imageURL){
		Bitmap bmp = null;
		
		try {
			bmp = BitmapFactory.decodeStream((InputStream) new URL(imageURL).getContent());
		} catch (MalformedURLException e) {
			// What if the URL is not well-formed?
			e.printStackTrace();
		} catch (IOException e) {
			// What if the Stream is not converted to Bitmap properly?
			e.printStackTrace();
		}
		
		return bmp;
	}

}
