package ams54.recommusic;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends Activity {

	Button startButton;
	ProgressBar pBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		//Setting up the start button
		startButton = (Button) findViewById(R.id.start_button);
		startButton.setOnClickListener(handler);

		//Grabbing the progressBar
		pBar = (ProgressBar) findViewById(R.id.pBar);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	//Declaring the button handler.
	OnClickListener handler = new OnClickListener(){
		@Override
		public void onClick(View v) {
			//Obtain track and artist from mp3 (create a method for that) and then submit the request, treat the request and display the request.
			pBar.setVisibility(View.VISIBLE);

			SongData task = new SongData();
			task.execute(MainActivity.this);

		};
	};

	protected static void doToast(Context c, String text){
		Toast.makeText(c, text, Toast.LENGTH_LONG).show();
	}

}
