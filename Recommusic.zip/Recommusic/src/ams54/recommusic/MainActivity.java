/**
 * TODO Write High-Level Description of MainActivity.
 * Read 
 * 		http://developer.android.com/training/efficient-downloads/index.html
 * 		http://developer.android.com/training/monitoring-device-state/index.html
 * 
 */
package ams54.recommusic;

import java.util.concurrent.ExecutionException;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends Activity {

	Button startButton;
	ListView lView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		//Setting up the start button
		startButton = (Button) findViewById(R.id.start_button);
		startButton.setOnClickListener(handler);
		
		lView = (ListView) findViewById(R.id.suggestedSongs);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	//Button onCLickListener.
	OnClickListener handler = new OnClickListener(){
		@Override
		public void onClick(View v) {
			//Obtain track and artist from mp3 (create a method for that) and then submit the request, treat the request and display the request.
			
			RandomSongRetriever task = new RandomSongRetriever(MainActivity.this);
			task.execute();
			try {
				Song song = task.get();
				
				ServiceHandler sHandler = new ServiceHandler();
				sHandler.execute(song);
				lView.setAdapter(new MediaAdapter(MainActivity.this, sHandler.get()));		
				lView.setVisibility(View.VISIBLE);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
	};
}
