/**
 * TODO Write High-Level Description of MainActivity.
 * Read 
 * 		http://developer.android.com/training/efficient-downloads/index.html
 * 		http://developer.android.com/training/monitoring-device-state/index.html
 * 
 */
package ams54.recommusic;

import java.util.concurrent.ExecutionException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {

	private Button startButton;
	private ListView lView;
	private Object actionMode;
	private Song listItem;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		//Setting up the start button
		startButton = (Button) findViewById(R.id.start_button);
		startButton.setOnClickListener(handler);

		lView = (ListView) findViewById(R.id.suggestedSongs);
		lView.setOnItemClickListener(listener);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	//Button onCLickListener.
	OnClickListener handler = new OnClickListener(){
		@Override
		public void onClick(View v) {			
			RandomSongRetriever task = new RandomSongRetriever(MainActivity.this);
			task.execute();
			try {
				Song song = task.get();

				ServiceHandler sHandler = new ServiceHandler();
				sHandler.execute(song);
				lView.setAdapter(new MediaAdapter(MainActivity.this, sHandler.get()));		
				lView.setVisibility(View.VISIBLE);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		};
	};

	// Action Mode Listener
	OnItemClickListener listener = new OnItemClickListener(){
		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
			ListAdapter ada = lView.getAdapter();
			listItem = (Song) ada.getItem(position);
			
			if (actionMode == null) {				
				//start the CAB using the ActionMode.Callback defined above
				actionMode = MainActivity.this
						.startActionMode(mActionModeCallback);
				lView.setSelected(true);
			}
		}
	};

	private Callback mActionModeCallback = new Callback() {

		// Called when the action mode is created; startActionMode() was called
		public boolean onCreateActionMode(ActionMode mode, Menu menu) {
			// inflate a menu resource providing context menu items
			MenuInflater inflater = mode.getMenuInflater();
			inflater.inflate(R.menu.contextual, menu);
			return true;
		}

		// called each time the action mode is shown. Always called after
		// onCreateActionMode, but
		// may be called multiple times if the mode is invalidated.
		public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
			return false; // Return false if nothing is done
		}

		// called when the user selects a contextual menu item
		public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
			switch (item.getItemId()) {
			case R.id.stream:
				Intent iStream = new Intent(Intent.ACTION_VIEW, Uri.parse(listItem.getStreamLink()));
				startActivity(iStream);
				mode.finish(); // Action picked, so close the CAB
			case R.id.buy:
				Intent iBuy = new Intent(Intent.ACTION_VIEW, Uri.parse(listItem.getBuyLink()));
				startActivity(iBuy);
				mode.finish();
			default:
				return false;
			}
		}

		// called when the user exits the action mode
		public void onDestroyActionMode(ActionMode mode) {
			actionMode = null;
		}
	};
}
