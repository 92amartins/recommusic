/**
 * TODO Write High-Level Description of MainActivity.
 * Read 
 * 		http://developer.android.com/training/efficient-downloads/index.html
 * 		http://developer.android.com/training/monitoring-device-state/index.html
 * 
 */
package ams54.recommusic;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;

public class MainActivity extends Activity {

	private ListView lView;
	private ProgressBar pBar;
	private Object actionMode;
	private Song listItem;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		lView = (ListView) findViewById(R.id.suggestedSongs);
		lView.setOnItemClickListener(listener);
		pBar = (ProgressBar) findViewById(R.id.pBar);
		
		songTask();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private void songTask(){
		final Handler h = new Handler();
		
		pBar.setVisibility(View.VISIBLE);
		
		Runnable runnable = new Runnable(){
			@Override
			public void run() {
				ServiceHandler serv = new ServiceHandler(randomSong());
				final ArrayList<Song> songs = serv.callWebService();
								
				h.post(new Runnable(){
					@Override
					public void run() {
						displayList(songs);
					}
				});
			}
		};
		new Thread(runnable).start();
	}

	private Song randomSong() {
		//Query Fields
		final Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
		final String[] proj = {MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.TITLE};
		final String where = MediaStore.Audio.Media.IS_MUSIC + " <> ?";
		final String sel[] = {"0"};

		ArrayList<String> artists = new ArrayList<String>();
		ArrayList<String> titles  = new ArrayList<String>();

		// TODO Instead of querying the whole set o Music, try to query and return just the selected song from the content provider. Cursor would have 1 row instead of 266..

		// Querying the MediaStore Content Provider and obtaining the set of songs in the phone
		Cursor cursor = getContentResolver().query(uri, proj, where, sel, null);

		// Random Index to select songs randomly
		int index = (int) (Math.random() * cursor.getCount());

		// Obtaining the set of artists and song names
		cursor.moveToFirst();

		do{
			artists.add(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)));
			titles.add(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)));
		}while(cursor.moveToNext());

		cursor.close();

		// Returning the chosen song
		return new Song(titles.get(index), artists.get(index));		
	}
	
	private void displayList(ArrayList<Song> items){
		pBar.setVisibility(View.GONE);
		lView.setAdapter(new MediaAdapter(this, items));
		lView.setVisibility(View.VISIBLE);
	}






	// Action Mode Listener
	OnItemClickListener listener = new OnItemClickListener(){
		@Override
		public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
			ListAdapter lAdapter = lView.getAdapter();
			listItem = (Song) lAdapter.getItem(position);

			if (actionMode == null) {				
				//start the CAB using the ActionMode.Callback defined above
				actionMode = MainActivity.this
						.startActionMode(mActionModeCallback);
				lView.setSelected(true);
			}
		}
	};

	private Callback mActionModeCallback = new Callback() {

		// Called when the action mode is created; startActionMode() was called
		public boolean onCreateActionMode(ActionMode mode, Menu menu) {
			// inflate a menu resource providing context menu items
			MenuInflater inflater = mode.getMenuInflater();
			inflater.inflate(R.menu.contextual, menu);
			return true;
		}

		// called each time the action mode is shown. Always called after
		// onCreateActionMode, but
		// may be called multiple times if the mode is invalidated.
		public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
			return false; // Return false if nothing is done
		}

		// called when the user selects a contextual menu item
		public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
			switch (item.getItemId()) {
			case R.id.stream:
				Intent iStream = new Intent(Intent.ACTION_VIEW, Uri.parse(listItem.getStreamLink()));
				startActivity(iStream);
				mode.finish(); // Action picked, so close the CAB
			case R.id.buy:
				Intent iBuy = new Intent(Intent.ACTION_VIEW, Uri.parse(listItem.getBuyLink()));
				startActivity(iBuy);
				mode.finish();
			default:
				return false;
			}
		}

		// called when the user exits the action mode
		public void onDestroyActionMode(ActionMode mode) {
			actionMode = null;
		}
	};
}
