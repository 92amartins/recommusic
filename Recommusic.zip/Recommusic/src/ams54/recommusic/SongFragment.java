package ams54.recommusic;

import java.util.ArrayList;

import android.app.Fragment;
import android.os.Bundle;

public class SongFragment extends Fragment {
	private ArrayList<Song> songList;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
	}
	
	public ArrayList<Song> getSongList() {
		return songList;
	}

	public void setSongList(ArrayList<Song> songList) {
		this.songList = songList;
	}
	
	
}
