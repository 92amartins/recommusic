/**
 * @author Andrei Martins Silva;
 * 
 * This class provides an implementation of a RandomSongRetriever which extends AsyncTask<Void, Void, Song> in order to run asynchronously.
 * Its main task is to retrieve artist and song name information about a random song in the phone.
 * To do this, it queries MediaStore Content Provider by using Context.getContentResolver.query() method. And then,
 * returns a Song object containing the information about the song;
 */
package ams54.recommusic;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.util.Log;

public class RandomSongRetriever extends AsyncTask<Void, Void, Song>{
	
	private Context context;
	
	//Query Fields
	private final Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
	private final String[] proj = {MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.TITLE};
	private final String where = MediaStore.Audio.Media.IS_MUSIC + " <> ?";
	private final String sel[] = {"0"};
	
	public RandomSongRetriever(Context cxt){
		context = cxt;		
	}
	
	@Override
	protected Song doInBackground(Void... params) {
		ArrayList<String> artists = new ArrayList<String>();
	    ArrayList<String> titles  = new ArrayList<String>();
	    
	    // Querying the MediaStore Content Provider and obtaining the set of songs in the phone
		Cursor cursor = context.getContentResolver().query(uri, proj, where, sel, null);
        
		// Random Index to select songs randomly
		int index = (int) (Math.random() * cursor.getCount());
		
		// Obtaining the set of artists and song names
		cursor.moveToFirst();
        
		do{
			artists.add(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)));
			titles.add(cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)));
		}while(cursor.moveToNext());
        
		cursor.close();
		
		// Returning the chosen song		
		return new Song(titles.get(index), artists.get(index));
	}
}
