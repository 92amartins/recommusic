package ams54.recommusic;

import java.util.Random;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.util.Log;

public class RandomSongRetriever {
	protected static Song retrieve(Context context) {
		ContentResolver cr;
		Cursor cursor;
		
		//Output Fields
		String title, artist;

		//Query Fields
		final Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
		final String[] proj = {MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.TITLE};
		final String where = MediaStore.Audio.Media.IS_MUSIC + " <> ?";
		final String sel[] = {"0"};

		cr = context.getContentResolver();
		// TODO Instead of querying the whole set o Music, try to query and return just the selected song from the content provider. Cursor would have 1 row instead of 266..

		// Obtaining the quantity of songs in the user's device
		cursor = cr.query(uri, new String[]{"count(*) AS count"}, null, null, null);
		cursor.moveToFirst();
		final int cursorSize = cursor.getInt(0);
		
		Log.i("CURSOR SIZE", Integer.toString(cursorSize));

		//Random Index to select songs randomly between [0,cursorSize)
		final Random random = new Random();
		int index = random.nextInt(cursorSize);

		final String sortOrder = BaseColumns._ID + " limit " + (index+1);

		Log.i("SORTORDER", sortOrder);
		// Querying the MediaStore Content Provider and obtaining the set of songs in the phone
		cursor = cr.query(uri, proj, where, sel, sortOrder);

		// Obtaining the set of artists and song names
		cursor.moveToFirst();
		cursor.move(index);

		title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
		artist = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));

		cursor.close();

		// Returning the chosen song
		return new Song(title, artist);		
	}

}
