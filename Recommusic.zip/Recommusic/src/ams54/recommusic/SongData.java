package ams54.recommusic;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.database.Cursor;
import android.os.AsyncTask;
import android.provider.MediaStore;
import android.util.Log;

public class SongData extends AsyncTask<Activity, Void, String[]>{

	@Override
	protected String[] doInBackground(Activity... params) {
		Cursor cursor;
	    String[] proj = {MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.MIME_TYPE, MediaStore.Audio.Media.DATE_ADDED, MediaStore.Audio.Media.DATE_MODIFIED};
	    String[] song = new String[5];
	    
		cursor = params[0].getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, null, null, null);
        
		cursor.moveToFirst();
        
		do{
			song[0] = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
	        song[1] = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
	        song[2] = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE));
	        song[3] = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED));
	        song[4] = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DATE_MODIFIED));
		}while(cursor.moveToNext());
        
		cursor.close();
        
		long epoch = Long.parseLong(song[3]);
		song[3] = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date(epoch*1000));
		epoch = Long.parseLong(song[4]);
		song[4] = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date(epoch*1000));
		
		return song;
	}
	
	@Override
	protected void onPostExecute(String[] result) {
		super.onPostExecute(result);
		
		Log.i(null, result[0] + "-" + result[1]);
		Log.i("MIME", result[2]);
		Log.i("Date_Added", result[3]);
		Log.i("Date_Modified", result[4]);
	}
	

}
